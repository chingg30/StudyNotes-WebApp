<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

include 'db.php';

$data = json_decode(file_get_contents("php://input"));

$id = (int)$data->id;
$title = $conn->real_escape_string($data->title);
$content = $conn->real_escape_string($data->content);
$subject = $conn->real_escape_string($data->subject);
$is_important = (int)$data->is_important;

$query = "UPDATE notes SET 
            title='$title',
            content='$content',
            subject='$subject',
            is_important=$is_important,
            updated_at=NOW()
          WHERE id=$id";

if ($conn->query($query)) {
    echo json_encode(['message' => 'Note updated']);
} else {
    echo json_encode(['error' => $conn->error]);
}
?>
