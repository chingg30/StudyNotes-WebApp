<?php
// Allow your React app origin or use * (less secure)
header("Access-Control-Allow-Origin: http://localhost:5173");

// Allow HTTP methods you accept
header("Access-Control-Allow-Methods: DELETE, OPTIONS");

// Allow these headers (important for Content-Type in your request)
header("Access-Control-Allow-Headers: Content-Type");

// For JSON response
header("Content-Type: application/json");

// Handle preflight OPTIONS request and exit early
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

include 'db.php';

$data = json_decode(file_get_contents("php://input"));
$id = (int)$data->id;

if ($conn->query("DELETE FROM notes WHERE id=$id")) {
    echo json_encode(['message' => 'Note deleted']);
} else {
    echo json_encode(['error' => $conn->error]);
}
?>
