<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Invalid request method']);
    exit;
}

$data = json_decode(file_get_contents("php://input"));

// Basic validation
if (
    empty($data->title) || 
    empty($data->content) || 
    empty($data->subject) || 
    empty($data->name)
) {
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

$title = $conn->real_escape_string($data->title);
$content = $conn->real_escape_string($data->content);
$subject = $conn->real_escape_string($data->subject);
$name = $conn->real_escape_string($data->name);
$is_important = isset($data->is_important) ? (int)$data->is_important : 0;

$query = "INSERT INTO notes (title, content, subject, name, is_important, created_at, updated_at)
          VALUES ('$title', '$content', '$subject', '$name', $is_important, NOW(), NOW())";

if ($conn->query($query)) {
    echo json_encode(['message' => 'Note created']);
} else {
    echo json_encode(['error' => 'Insert failed: ' . $conn->error]);
}
?>
