<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

include 'db.php'; // Make sure this connects to your DB

$targetDir = "uploads/";

if (!isset($_FILES["profile"]) || !isset($_POST["userName"])) {
    echo json_encode(["error" => "No file uploaded or username missing"]);
    exit;
}

$file = $_FILES["profile"];
$userName = $conn->real_escape_string($_POST["userName"]);
$fileName = basename($file["name"]);
$targetFilePath = $targetDir . uniqid() . "_" . $fileName;

if (move_uploaded_file($file["tmp_name"], $targetFilePath)) {
    // Update user record with new profile image path
    $query = "UPDATE users SET profile_image = '$targetFilePath' WHERE name = '$userName'";

    if ($conn->query($query)) {
        echo json_encode(["success" => true, "path" => $targetFilePath]);
    } else {
        echo json_encode(["error" => "Failed to update profile image in DB: " . $conn->error]);
    }
} else {
    echo json_encode(["error" => "Failed to upload image"]);
}
?>
