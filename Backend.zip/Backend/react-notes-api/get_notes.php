<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
include 'db.php';

$name = isset($_GET['name']) ? $conn->real_escape_string($_GET['name']) : '';

if (!$name) {
    echo json_encode(['error' => 'Missing user name']);
    exit;
}

$result = $conn->query("SELECT * FROM notes WHERE name = '$name' ORDER BY created_at DESC");
$notes = [];

while ($row = $result->fetch_assoc()) {
    $row['is_important'] = (int) $row['is_important']; // Ensures JS receives a number
    $notes[] = $row;
}

echo json_encode($notes);
?>
