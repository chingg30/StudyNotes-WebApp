<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include 'db.php';

$username = isset($_GET['username']) ? $conn->real_escape_string($_GET['username']) : '';

if (!$username) {
    echo json_encode(['error' => 'Username is required']);
    exit;
}

$sql = "SELECT name, profile_image FROM users WHERE name = '$username' LIMIT 1";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $user = $result->fetch_assoc();
    echo json_encode([
        'name' => $user['name'],
        'profileImage' => $user['profile_image']
    ]);
} else {
    echo json_encode(['error' => 'User not found']);
}
?>
