<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include 'db.php';

$name = $_GET['name'] ?? '';

if (empty($name)) {
    echo json_encode(['error' => 'Missing name']);
    exit;
}

$name = $conn->real_escape_string($name);
$result = $conn->query("SELECT profile_image FROM users WHERE name = '$name'");

if ($result && $row = $result->fetch_assoc()) {
    echo json_encode(['imagePath' => $row['profile_image']]);
} else {
    echo json_encode(['error' => 'User not found']);
}
?>
