<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

include 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $result = $conn->query("SELECT * FROM notes ORDER BY id DESC");
        $notes = array();
        while ($row = $result->fetch_assoc()) {
            $notes[] = $row;
        }
        echo json_encode($notes);
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $title = $data['title'];
        $content = $data['content'];
        $is_important = $data['is_important'] ? 1 : 0;

        $stmt = $conn->prepare("INSERT INTO notes (title, content, is_important) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $title, $content, $is_important);
        $stmt->execute();
        echo json_encode(["success" => true]);
        break;

    case 'PUT':
        $data = json_decode(file_get_contents("php://input"), true);
        $id = $data['id'];
        $title = $data['title'];
        $content = $data['content'];
        $is_important = $data['is_important'] ? 1 : 0;

        $stmt = $conn->prepare("UPDATE notes SET title=?, content=?, is_important=? WHERE id=?");
        $stmt->bind_param("ssii", $title, $content, $is_important, $id);
        $stmt->execute();
        echo json_encode(["success" => true]);
        break;

    case 'DELETE':
        parse_str(file_get_contents("php://input"), $data);
        $id = $data['id'];

        $stmt = $conn->prepare("DELETE FROM notes WHERE id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        echo json_encode(["success" => true]);
        break;
}
?>
