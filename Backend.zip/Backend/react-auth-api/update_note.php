<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");
include 'db_connection.php';

$data = json_decode(file_get_contents('php://input'), true);

$id = isset($data['id']) ? intval($data['id']) : 0;
$title = isset($data['title']) ? trim($data['title']) : '';
$subject = isset($data['subject']) ? trim($data['subject']) : '';
$content = isset($data['content']) ? trim($data['content']) : '';

if ($id <= 0 || $title === '' || $content === '') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
    exit;
}

$sql = "UPDATE notes SET title = ?, subject = ?, content = ?, updated_at = NOW() WHERE id = ?";
$stmt = $pdo->prepare($sql);

if ($stmt->execute([$title, $subject, $content, $id])) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Update failed']);
}
