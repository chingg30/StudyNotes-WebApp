<?php
$host = "localhost";
$db = "react_auth"; // Use your DB name
$user = "root";
$pass = ""; // Default WAMP password

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
