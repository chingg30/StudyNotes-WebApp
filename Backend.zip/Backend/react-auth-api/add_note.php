<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

include 'db_connection.php';

$data = json_decode(file_get_contents('php://input'), true);

$title = isset($data['title']) ? trim($data['title']) : '';
$subject = isset($data['subject']) ? trim($data['subject']) : '';
$content = isset($data['content']) ? trim($data['content']) : '';
$name = isset($data['name']) ? trim($data['name']) : '';

if ($title === '' || $content === '' || $name === '') {
    echo json_encode(['status' => 'error', 'message' => 'Title, content, and name are required']);
    exit;
}

try {
    $sql = "INSERT INTO notes (title, subject, name, content, created_at, updated_at, is_important)
            VALUES (?, ?, ?, ?, NOW(), NOW(), 0)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$title, $subject, $name, $content]);

    echo json_encode(['status' => 'success']);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Failed to insert note']);
}
?>
