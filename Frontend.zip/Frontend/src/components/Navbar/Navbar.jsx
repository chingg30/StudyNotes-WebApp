import React from 'react';
import ProfileInfo from '../Cards/ProfileInfo';
import SearchBar from '../SearchBar/SearchBar';
import { useNavigate } from 'react-router-dom';

const Navbar = ({ searchQuery, setSearchQuery }) => {
  const navigate = useNavigate();

  const handleSearch = () => {
    // Optional: You can add logic on search icon click if needed
    console.log('Searching for:', searchQuery);
  };

  const onClearSearch = () => {
    setSearchQuery('');
  };

  return (
    <div className="bg-blue-300 flex items-center justify-between px-6 py-2 drop-shadow-2xl">
      <h2 className="text-xl font-medium text-black py-2">Study Notes</h2>
      <SearchBar
        value={searchQuery}
        onChange={({ target }) => setSearchQuery(target.value)}
        onSearch={handleSearch}
        onClear={onClearSearch}
        placeholder="Search notes by title or content..."
      />
      <ProfileInfo onLogout={() => navigate('/login')} />
    </div>
  );
};

export default Navbar;
