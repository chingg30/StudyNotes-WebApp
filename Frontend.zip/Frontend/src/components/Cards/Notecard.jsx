import React from "react";
import { MdOutlinePushPin, MdCreate, MdDelete } from "react-icons/md";

const Notecard = ({
  title,
  date,
  time,
  content,
  isPinned,
  OnEdit,
  OnDelete,
  onPinNote,
}) => {
  return (
    <div className="border rounded p-4 bg-white hover:shadow-xl transition-all ease-in-out relative">
      <MdOutlinePushPin
        className={`absolute top-2 right-2 text-2xl cursor-pointer ${
          isPinned ? "text-blue-600" : "text-gray-300"
        }`}
        onClick={(e) => {
          e.stopPropagation(); // Prevent bubbling
          onPinNote();
        }}
      />
      <h6 className="text-sm font-semibold">{title}</h6>
      <p className="text-sm text-black mt-2">
        {content?.slice(0, 60)}
        {content?.length > 60 ? "..." : ""}
      </p>

      <div className="flex items-center justify-between mt-4">
        <div className="flex flex-col text-xs text-slate-500">
          <span>{date}</span>
          <span>{time}</span>
        </div>

        <div className="flex items-center gap-2">
          <MdCreate
            className="hover:text-green-600 cursor-pointer"
            onClick={OnEdit}
          />
          <MdDelete
            className="hover:text-red-500 cursor-pointer"
            onClick={OnDelete}
          />
        </div>
      </div>
    </div>
  );
};

export default Notecard;
