import React, { useEffect, useState, useRef } from 'react';

const ProfileInfo = ({ onLogout }) => {
  const [name, setName] = useState('User');
  const [image, setImage] = useState(null);
  const fileInputRef = useRef();

  useEffect(() => {
    const username = localStorage.getItem('userName');
    if (!username) return;

    // Fetch user profile info from backend
    fetch(`http://localhost/react-notes-api/get_user_profile.php?username=${encodeURIComponent(username)}`)
      .then(res => res.json())
      .then(data => {
        if (!data.error) {
          setName(data.name || 'User');
          if (data.profileImage) {
            setImage(`http://localhost/react-notes-api/${data.profileImage}`);
          }
        }
      })
      .catch(console.error);
  }, []);

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('profile', file);
    formData.append('userName', name);

    try {
      const res = await fetch('http://localhost/react-notes-api/upload_profile.php', {
        method: 'POST',
        body: formData,
      });

      const data = await res.json();
      if (data.success && data.path) {
        setImage(`http://localhost/react-notes-api/${data.path}`);
      } else {
        alert(data.error || 'Failed to upload image.');
      }
    } catch (err) {
      console.error('Upload failed:', err);
    }
  };

  return (
    <div className="flex items-center gap-3">
      <input
        type="file"
        accept="image/*"
        onChange={handleImageUpload}
        ref={fileInputRef}
        style={{ display: 'none' }}
      />
      <div onClick={() => fileInputRef.current.click()} className="cursor-pointer">
        {image ? (
          <img
            src={image}
            alt="Profile"
            className="w-12 h-12 rounded-full object-cover border-2 border-slate-300"
          />
        ) : (
          <div className="w-12 h-12 flex items-center justify-center rounded-full text-slate-950 font-medium bg-blue-500">
            {name
              .split(' ')
              .map(n => n[0])
              .join('')
              .toUpperCase()}
          </div>
        )}
      </div>

      <div>
        <p className="text-sm font-medium">{name}</p>
        <button
          className="text-sm text-gray-800 underline"
          onClick={() => {
            localStorage.clear();
            onLogout();
          }}
        >
          Logout
        </button>
      </div>
    </div>
  );
};

export default ProfileInfo;
