import React, { useState, useEffect } from 'react';
import { MdClose } from 'react-icons/md';

const AddEditNotes = ({ noteData, type, onClose }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState('');

  const userName = localStorage.getItem('userName') || 'User';

  useEffect(() => {
    if (type === 'edit' && noteData) {
      setTitle(noteData.title);
      setContent(noteData.content);
    } else {
      setTitle('');
      setContent('');
    }
  }, [noteData, type]);

  // Add Note
  const addNewNote = async () => {
    try {
      const res = await fetch('http://localhost/react-notes-api/create_note.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title,
          content,
          subject: 'General',
          is_important: 0,
          name: userName,
        }),
      });

      const data = await res.json();
      if (data.message) {
        setSuccessMessage('Note saved successfully!');
        setTitle('');
        setContent('');
        setTimeout(() => {
          setSuccessMessage('');
          onClose();
        }, 1500);
      } else {
        setError(data.error || 'Failed to add note.');
      }
    } catch (err) {
      console.error(err);
      setError('Something went wrong while saving the note.');
    }
  };

//Edit Note
const editNote = async () => {
  try {
    const res = await fetch('http://localhost/react-notes-api/update_note.php', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        id: noteData.id,
        title,
        content,
        subject: 'General',
        is_important: noteData.is_important, // ✅ Preserve pin status
      }),
    });

    const data = await res.json();
    if (data.message) {
      setSuccessMessage('Note updated successfully!');
      setTimeout(() => {
        setSuccessMessage('');
        onClose();
      }, 1500);
    } else {
      setError(data.error || 'Failed to update note.');
    }
  } catch (err) {
    console.error(err);
    setError('Something went wrong while updating the note.');
  }
};

  return (
    <div className='relative'>
      <button
        className='w-10 h-10 rounded-full flex items-center justify-center absolute -top-3 -right-3 hover:bg-red-300'
        onClick={onClose}
      >
        <MdClose className='text-xl text-slate-400' />
      </button>

      <div className='flex flex-col gap-2'>
        <label className='input-label'>TITLE</label>
        <input
          type='text'
          className='text-2xl text-slate-950 outline-none'
          placeholder='Your title'
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
      </div>

      <div className='flex flex-col gap-2 mt-4'>
        <label className='input-label'>CONTENT</label>
        <textarea
          className='text-sm text-slate-950 outline-none bg-slate-50 p-2 rounded'
          placeholder='Content'
          rows={10}
          value={content}
          onChange={(e) => setContent(e.target.value)}
        />
      </div>

      {error && <p className='text-red-500 text-xs pt-4'>{error}</p>}
      {successMessage && <p className='text-green-600 text-sm pt-4'>{successMessage}</p>}

      <button
        className='w-full bg-blue-600 hover:bg-blue-700 text-white font-medium mt-5 p-3 rounded'
        onClick={type === 'edit' ? editNote : addNewNote}
      >
        {type === 'edit' ? 'EDIT' : 'ADD'}
      </button>
    </div>
  );
};

export default AddEditNotes;
