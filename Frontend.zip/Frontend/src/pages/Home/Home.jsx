import React, { useState, useEffect } from 'react';
import Modal from 'react-modal';
import Navbar from '../../components/Navbar/Navbar';
import Notecard from '../../components/Cards/Notecard';
import { MdAdd } from 'react-icons/md';
import AddEditNotes from './AddEditNotes';

Modal.setAppElement('#root');

// Bubble background component
const BubblesBackground = () => {
  const bubbles = Array.from({ length: 20 });
  return (
    <div className="bubbles-background fixed top-0 left-0 w-full h-full overflow-hidden -z-10 pointer-events-none">
      {bubbles.map((_, index) => {
        const size = Math.floor(Math.random() * 30) + 10;
        const left = Math.floor(Math.random() * 100);
        const duration = Math.floor(Math.random() * 10) + 10;
        const delay = Math.floor(Math.random() * 20);
        return (
          <span
            key={index}
            className="bubble"
            style={{
              width: size + 'px',
              height: size + 'px',
              left: `${left}%`,
              animationDuration: `${duration}s`,
              animationDelay: `${delay}s`,
            }}
          ></span>
        );
      })}
    </div>
  );
};

const Home = () => {
  const [notes, setNotes] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [openAddEditModal, setOpenAddEditModal] = useState({
    isShown: false,
    type: 'add',
    data: null,
  });
  const [filter, setFilter] = useState('all'); // 'all' or 'important'

  const userName = localStorage.getItem('userName') || 'User';

  const fetchNotes = async () => {
    try {
      const res = await fetch(`http://localhost/react-notes-api/get_notes.php?name=${encodeURIComponent(userName)}`);
      const data = await res.json();
      if (res.ok) {
        setNotes(data);
      } else {
        console.error(data.error || 'Failed to fetch notes');
      }
    } catch (error) {
      console.error('Error fetching notes:', error);
    }
  };

  useEffect(() => {
    fetchNotes();
  }, []);

  const togglePinNote = async (note) => {
    try {
      const updatedNote = {
        ...note,
        is_important: note.is_important === 1 ? 0 : 1,
      };
      const res = await fetch('http://localhost/react-notes-api/update_note.php', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedNote),
      });
      const data = await res.json();
      if (data.message) {
        setNotes((prevNotes) =>
          prevNotes.map((n) => (n.id === note.id ? updatedNote : n))
        );
      } else {
        alert(data.error || 'Failed to update note pin status');
      }
    } catch (error) {
      console.error('Error toggling pin:', error);
      alert('Error toggling pin status');
    }
  };

  const deleteNote = async (id) => {
    if (!window.confirm('Are you sure you want to delete this note?')) return;
    try {
      const res = await fetch('http://localhost/react-notes-api/delete_note.php', {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ id }),
      });
      const data = await res.json();
      if (data.message) {
        fetchNotes();
      } else {
        alert(data.error || 'Failed to delete note');
      }
    } catch (err) {
      console.error('Delete failed', err);
      alert('Error deleting note');
    }
  };

  const filteredNotes = notes
    .filter((note) => {
      const query = searchQuery.toLowerCase();
      return (
        note.title.toLowerCase().includes(query) ||
        note.content.toLowerCase().includes(query)
      );
    })
    .filter((note) => {
      if (filter === 'important') return note.is_important === 1;
      return true;
    });

  return (
    <>
      <BubblesBackground />
      <Navbar searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 min-h-screen bg-gray-100 shadow-md p-4">
          <h2 className="text-lg font-bold mb-4">📁 Menu</h2>
          <button
            className={`block w-full text-left px-4 py-2 rounded hover:bg-blue-200 ${filter === 'all' ? 'bg-blue-300 font-semibold' : ''}`}
            onClick={() => setFilter('all')}
          >
            📝 All Notes
          </button>
          <button
            className={`block w-full text-left px-4 py-2 mt-2 rounded hover:bg-blue-200 ${filter === 'important' ? 'bg-blue-300 font-semibold' : ''}`}
            onClick={() => setFilter('important')}
          >
            📌 Important Notes
          </button>
        </div>

        {/* Main Notes Area */}
        <div className="flex-1 p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
            {filteredNotes.length > 0 ? (
              filteredNotes.map((note) => (
                <Notecard
                  key={note.id}
                  title={note.title}
                  date={note.created_at}
                  time={note.updated_at}
                  content={note.content}
                  isPinned={note.is_important === 1}
                  OnEdit={() => setOpenAddEditModal({ isShown: true, type: 'edit', data: note })}
                  OnDelete={() => deleteNote(note.id)}
                  onPinNote={() => togglePinNote(note)}
                />
              ))
            ) : (
              <p className="col-span-3 text-center text-gray-500">No notes found</p>
            )}
          </div>
        </div>
      </div>

      {/* Add Note Button */}
      <button
        className="w-16 h-16 flex items-center justify-center rounded-2xl bg-blue-600 hover:bg-blue-700 fixed right-10 bottom-10 z-50"
        onClick={() => setOpenAddEditModal({ isShown: true, type: 'add', data: null })}
      >
        <MdAdd className="text-[32px] text-white" />
      </button>

      {/* Modal */}
      <Modal
        isOpen={openAddEditModal.isShown}
        onRequestClose={() => setOpenAddEditModal({ ...openAddEditModal, isShown: false })}
        style={{ overlay: { backgroundColor: 'rgba(0,0,0,0.2)' } }}
        contentLabel="Add/Edit Notes"
        className="w-[40%] max-h-3/4 bg-white rounded-md mx-auto mt-14 p-5 overflow-scroll"
      >
        <AddEditNotes
          type={openAddEditModal.type}
          noteData={openAddEditModal.data}
          onClose={() => {
            setOpenAddEditModal({ isShown: false, type: 'add', data: null });
            fetchNotes();
          }}
        />
      </Modal>
    </>
  );
};

export default Home;
