
clone the file first in your file 


How to run?

cd notes-frontend
npm i
npm run dev



